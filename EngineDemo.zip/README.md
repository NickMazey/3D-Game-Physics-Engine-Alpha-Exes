Notice:

This is a development demonstration build of a game / game engine I'm working on, 
please don't re-distribute it.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

About the demo:

FPS game in which it is a 1v1 first to 10 match.
To take control of the game, right click the window (right clicking also makes you stop controlling the game).
The game will appear to run slow if you are playing the game below a 125hz refresh rate.
Your ammo is represented by the colour of your weapon, with the weapon starting white and gradually getting darker as you
run out of loaded ammo (reload by pressing r).
Once you defeat your opponent the score bar at the top will gain a square and you will be reset to your starting position /
ammo count.
The opponent player moves / jumps / shoots randomly.
Once you have reached the score limit, the game will become unplayable as the opponent will disappear but the game will not reset.
You can also become soft locked if you use all of your ammo without defeating your opponent.
To restart the demo you need to close and re-open the program.
The game runs at 2560*1440 with v-sync enabled and uses 4x MSAA.
